# Specification

## Summary
**Goal:** Build a modern, clean, responsive marketing website for “MilletBowl” with warm, trustworthy visuals and core pages (info, plans, and contact/order form) plus backend persistence for submissions.

**Planned changes:**
- Create a consistent site-wide visual system (yellow/white/green palette, clean typography, generous whitespace, accessible contrast) and responsive layouts.
- Implement pages/sections: Landing (with tagline, intro, CTA to Contact/Order), About (with lifestyle/health explanation and explicit ingredient list), Personalized Diet Plans (example daily plan), Target Customers, Subscription Plans (weekly/monthly + customization concept), Hygiene & Organic Promise.
- Add site navigation to reach Home, About, Personalized Diet Plans, Subscription Plans, and Contact/Order with clear active state.
- Build a Contact/Order form (name, health condition, subscription interest) with required-field validation and success/error UI.
- Add a single Motoko actor backend to store submissions with timestamp and provide methods to create and list submissions.
- Wire the frontend form to the backend using React Query mutation so UI states reflect real backend responses.
- Add and reference generated static food/health visuals from `frontend/public/assets/generated` (hero + at least one additional section).

**User-visible outcome:** Users can browse MilletBowl’s homepage and informational pages, view example diet and subscription options, and submit a validated contact/order request that is stored in the backend with visible success/error feedback.
