import { RouterProvider, createRouter, createRoute, createRootRoute } from '@tanstack/react-router';
import SiteLayout from './components/SiteLayout';
import HomePage from './pages/HomePage';
import AboutPage from './pages/AboutPage';
import PersonalizedDietPlansPage from './pages/PersonalizedDietPlansPage';
import SubscriptionPlansPage from './pages/SubscriptionPlansPage';
import ContactOrderPage from './pages/ContactOrderPage';

const rootRoute = createRootRoute({
  component: SiteLayout
});

const indexRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/',
  component: HomePage
});

const aboutRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/about',
  component: AboutPage
});

const dietPlansRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/diet-plans',
  component: PersonalizedDietPlansPage
});

const subscriptionRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/subscription',
  component: SubscriptionPlansPage
});

const contactRoute = createRoute({
  getParentRoute: () => rootRoute,
  path: '/contact',
  component: ContactOrderPage
});

const routeTree = rootRoute.addChildren([
  indexRoute,
  aboutRoute,
  dietPlansRoute,
  subscriptionRoute,
  contactRoute
]);

const router = createRouter({ routeTree });

declare module '@tanstack/react-router' {
  interface Register {
    router: typeof router;
  }
}

export default function App() {
  return <RouterProvider router={router} />;
}
