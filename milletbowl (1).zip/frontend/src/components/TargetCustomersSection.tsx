import { Users, Heart, Briefcase, Sparkles } from 'lucide-react';

export default function TargetCustomersSection() {
  const customers = [
    {
      icon: Heart,
      title: 'Diabetic Patients',
      description:
        'Specially designed low-GI meals that help manage blood sugar levels naturally and effectively'
    },
    {
      icon: Users,
      title: 'Elderly People',
      description:
        'Easy-to-digest, nutrient-rich meals that support healthy aging and maintain vitality'
    },
    {
      icon: Briefcase,
      title: 'Software/Corporate Employees',
      description:
        'Convenient, healthy meals delivered to your doorstep, perfect for busy professionals'
    },
    {
      icon: Sparkles,
      title: 'Health-Conscious Individuals',
      description:
        'Clean, organic nutrition for those committed to maintaining optimal health and wellness'
    }
  ];

  return (
    <section className="py-16 md:py-24">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">Who We Serve</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our personalized meal plans are designed for diverse health needs
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {customers.map((customer, index) => (
            <div
              key={index}
              className="bg-card rounded-xl p-8 shadow-sm hover:shadow-warm transition-all border border-border/50"
            >
              <customer.icon className="h-10 w-10 text-primary mb-4" />
              <h3 className="text-2xl font-semibold mb-3">{customer.title}</h3>
              <p className="text-muted-foreground">{customer.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
