import { CheckCircle2, Leaf, Shield } from 'lucide-react';

export default function HygienePromiseSection() {
  const promises = [
    {
      icon: CheckCircle2,
      title: 'No Refined Sugar',
      description: 'We use only natural sweeteners and whole grains to keep your blood sugar stable'
    },
    {
      icon: Shield,
      title: 'No Preservatives',
      description: 'Freshly cooked meals delivered daily with no artificial additives or chemicals'
    },
    {
      icon: Leaf,
      title: 'Organic Ingredients',
      description: '100% certified organic millets, vegetables, and spices sourced from trusted farms'
    }
  ];

  return (
    <section className="py-16 md:py-24 bg-gradient-to-br from-accent/10 to-primary/10">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Our Hygiene & Organic Promise
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Your health is our priority. We maintain the highest standards of quality and purity.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {promises.map((promise, index) => (
            <div key={index} className="text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
                <promise.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{promise.title}</h3>
              <p className="text-muted-foreground">{promise.description}</p>
            </div>
          ))}
        </div>
        <div className="mt-12 text-center">
          <img
            src="/assets/generated/milletbowl-icons-set.dim_1024x1024.png"
            alt="Quality and hygiene icons"
            className="inline-block rounded-xl shadow-lg max-w-md w-full h-auto"
          />
        </div>
      </div>
    </section>
  );
}
