import { Wheat, TrendingDown, Activity } from 'lucide-react';

export default function AboutPage() {
  const millets = [
    'Ragi (Finger Millet)',
    'Jowar (Sorghum)',
    'Foxtail Millet',
    'Barnyard Millet',
    'Kodo Millet',
    'Little Millet',
    'Proso Millet',
    'Browntop Millet',
    'Amaranth',
    'Buckwheat'
  ];

  return (
    <div className="py-16 md:py-24">
      <div className="container max-w-5xl">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">About MilletBowl</h1>
          <p className="text-xl text-muted-foreground">
            Rediscovering ancient wisdom for modern health challenges
          </p>
        </div>

        {/* The Problem */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-display font-bold mb-6">The Modern Health Crisis</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>
                  Today's fast-paced lifestyle has led to a dramatic increase in lifestyle-related
                  diseases. Sedentary work habits, processed foods, and high-stress environments
                  have created a perfect storm for health issues.
                </p>
                <div className="space-y-3 pt-4">
                  <div className="flex items-start gap-3">
                    <TrendingDown className="h-6 w-6 text-destructive flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Diabetes Epidemic</h3>
                      <p className="text-sm">
                        Rising blood sugar levels from refined carbohydrates and sugar-laden diets
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Activity className="h-6 w-6 text-destructive flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Obesity & Weight Gain</h3>
                      <p className="text-sm">
                        Lack of physical activity combined with calorie-dense processed foods
                      </p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Wheat className="h-6 w-6 text-destructive flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold text-foreground mb-1">Digestive Issues</h3>
                      <p className="text-sm">
                        Poor gut health from low-fiber diets and artificial additives
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-muted/50 rounded-2xl p-8 border border-border">
              <h3 className="text-xl font-semibold mb-4">Common Symptoms</h3>
              <ul className="space-y-2 text-muted-foreground">
                <li className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-destructive"></span>
                  Chronic fatigue and low energy
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-destructive"></span>
                  Unstable blood sugar levels
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-destructive"></span>
                  Weight management struggles
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-destructive"></span>
                  Digestive discomfort
                </li>
                <li className="flex items-center gap-2">
                  <span className="h-2 w-2 rounded-full bg-destructive"></span>
                  Increased disease risk
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* The Solution */}
        <section className="mb-16">
          <div className="bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 md:p-12">
            <h2 className="text-3xl font-display font-bold mb-6 text-center">
              The MilletBowl Solution
            </h2>
            <p className="text-lg text-muted-foreground text-center mb-8 max-w-3xl mx-auto">
              Instead of relying on medication, we believe in addressing the root cause through
              nutrition. Our approach combines traditional Indian millets with organic ingredients
              to create meals that naturally support your body's healing processes.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-card rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-primary mb-2">Low GI</div>
                <p className="text-sm text-muted-foreground">
                  Millets have a low glycemic index, helping stabilize blood sugar
                </p>
              </div>
              <div className="bg-card rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-primary mb-2">High Fiber</div>
                <p className="text-sm text-muted-foreground">
                  Rich in dietary fiber for better digestion and gut health
                </p>
              </div>
              <div className="bg-card rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-primary mb-2">Nutrient Dense</div>
                <p className="text-sm text-muted-foreground">
                  Packed with vitamins, minerals, and antioxidants
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Millets Section */}
        <section>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="/assets/generated/milletbowl-millets.dim_1400x900.png"
                alt="Assorted Indian millets and grains"
                className="rounded-2xl shadow-xl w-full h-auto"
              />
            </div>
            <div>
              <h2 className="text-3xl font-display font-bold mb-6">
                Our Traditional Millet Selection
              </h2>
              <p className="text-muted-foreground mb-6">
                We carefully source and prepare a variety of ancient grains, each with unique
                nutritional benefits and flavors. These superfoods have sustained generations and
                are now recognized globally for their health benefits.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {millets.map((millet, index) => (
                  <div
                    key={index}
                    className="flex items-center gap-2 bg-muted/50 rounded-lg px-4 py-2"
                  >
                    <Wheat className="h-4 w-4 text-primary flex-shrink-0" />
                    <span className="text-sm font-medium">{millet}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
