import { useState } from 'react';
import { useCreateSubmission } from '../hooks/useCreateSubmission';
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react';

export default function ContactOrderPage() {
  const [formData, setFormData] = useState({
    name: '',
    healthCondition: '',
    subscriptionInterest: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const { mutate: createSubmission, isPending, isSuccess, isError, error } = useCreateSubmission();

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }

    if (!formData.healthCondition.trim()) {
      newErrors.healthCondition = 'Please describe your health condition';
    }

    if (!formData.subscriptionInterest.trim()) {
      newErrors.subscriptionInterest = 'Please select your subscription interest';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    createSubmission(
      {
        name: formData.name,
        healthCondition: formData.healthCondition,
        subscriptionInterest: formData.subscriptionInterest
      },
      {
        onSuccess: () => {
          setFormData({ name: '', healthCondition: '', subscriptionInterest: '' });
          setErrors({});
        }
      }
    );
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) {
      setErrors((prev) => ({ ...prev, [name]: '' }));
    }
  };

  return (
    <div className="py-16 md:py-24">
      <div className="container max-w-3xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">
            Start Your Healthy Journey
          </h1>
          <p className="text-xl text-muted-foreground">
            Fill out the form below and our nutrition experts will contact you to create your
            personalized meal plan.
          </p>
        </div>

        {/* Success Message */}
        {isSuccess && (
          <div className="mb-8 bg-accent/10 border border-accent rounded-lg p-6 flex items-start gap-4">
            <CheckCircle2 className="h-6 w-6 text-accent flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-accent-foreground mb-1">
                Thank you for your interest!
              </h3>
              <p className="text-sm text-muted-foreground">
                We've received your information and our team will contact you within 24 hours to
                discuss your personalized meal plan.
              </p>
            </div>
          </div>
        )}

        {/* Error Message */}
        {isError && (
          <div className="mb-8 bg-destructive/10 border border-destructive rounded-lg p-6 flex items-start gap-4">
            <AlertCircle className="h-6 w-6 text-destructive flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-semibold text-destructive-foreground mb-1">
                Submission Failed
              </h3>
              <p className="text-sm text-muted-foreground">
                {error?.message || 'Something went wrong. Please try again.'}
              </p>
            </div>
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-card rounded-2xl p-8 shadow-sm border border-border/50">
          <div className="space-y-6">
            {/* Name Field */}
            <div>
              <label htmlFor="name" className="block text-sm font-medium mb-2">
                Full Name <span className="text-destructive">*</span>
              </label>
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className={`w-full px-4 py-3 rounded-lg border bg-background transition-colors ${
                  errors.name ? 'border-destructive' : 'border-input'
                } focus:outline-none focus:ring-2 focus:ring-ring`}
                placeholder="Enter your full name"
                disabled={isPending}
              />
              {errors.name && (
                <p className="mt-1 text-sm text-destructive">{errors.name}</p>
              )}
            </div>

            {/* Health Condition Field */}
            <div>
              <label htmlFor="healthCondition" className="block text-sm font-medium mb-2">
                Health Condition <span className="text-destructive">*</span>
              </label>
              <textarea
                id="healthCondition"
                name="healthCondition"
                value={formData.healthCondition}
                onChange={handleChange}
                rows={4}
                className={`w-full px-4 py-3 rounded-lg border bg-background transition-colors resize-none ${
                  errors.healthCondition ? 'border-destructive' : 'border-input'
                } focus:outline-none focus:ring-2 focus:ring-ring`}
                placeholder="Please describe your health condition (e.g., diabetes, obesity, digestive issues, etc.)"
                disabled={isPending}
              />
              {errors.healthCondition && (
                <p className="mt-1 text-sm text-destructive">{errors.healthCondition}</p>
              )}
            </div>

            {/* Subscription Interest Field */}
            <div>
              <label htmlFor="subscriptionInterest" className="block text-sm font-medium mb-2">
                Subscription Interest <span className="text-destructive">*</span>
              </label>
              <select
                id="subscriptionInterest"
                name="subscriptionInterest"
                value={formData.subscriptionInterest}
                onChange={handleChange}
                className={`w-full px-4 py-3 rounded-lg border bg-background transition-colors ${
                  errors.subscriptionInterest ? 'border-destructive' : 'border-input'
                } focus:outline-none focus:ring-2 focus:ring-ring`}
                disabled={isPending}
              >
                <option value="">Select a plan</option>
                <option value="weekly">Weekly Plan</option>
                <option value="monthly">Monthly Plan</option>
                <option value="custom">Custom Plan</option>
                <option value="consultation">Just Consultation</option>
              </select>
              {errors.subscriptionInterest && (
                <p className="mt-1 text-sm text-destructive">{errors.subscriptionInterest}</p>
              )}
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isPending}
              className="w-full bg-primary text-primary-foreground rounded-lg px-6 py-3 font-semibold hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isPending ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Request'
              )}
            </button>
          </div>
        </form>

        {/* Additional Info */}
        <div className="mt-8 text-center text-sm text-muted-foreground">
          <p>
            By submitting this form, you agree to be contacted by our team regarding your meal plan
            inquiry.
          </p>
        </div>
      </div>
    </div>
  );
}
