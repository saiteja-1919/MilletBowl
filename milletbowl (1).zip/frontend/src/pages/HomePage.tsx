import { Link } from '@tanstack/react-router';
import { ArrowRight, Leaf, Heart, Users, Shield } from 'lucide-react';
import TargetCustomersSection from '../components/TargetCustomersSection';
import HygienePromiseSection from '../components/HygienePromiseSection';

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-secondary/30 via-background to-accent/20">
        <div className="container py-16 md:py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6 animate-fade-in">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-display font-bold text-balance leading-tight">
                Traditional Nutrition. Modern Convenience.
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground text-balance">
                Discover the power of ancient Indian millets with our freshly cooked, personalized
                meal plans designed specifically for diabetic patients, elderly individuals, and
                busy professionals seeking better health through natural nutrition.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center rounded-lg bg-primary px-8 py-3 text-base font-semibold text-primary-foreground shadow-warm hover:bg-primary/90 transition-all"
                >
                  Start Your Healthy Plan
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
                <Link
                  to="/about"
                  className="inline-flex items-center justify-center rounded-lg border-2 border-primary px-8 py-3 text-base font-semibold text-primary hover:bg-primary/10 transition-all"
                >
                  Learn More
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="/assets/generated/milletbowl-hero.dim_1600x900.png"
                alt="Healthy millet bowl with fresh vegetables"
                className="rounded-2xl shadow-2xl w-full h-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 md:py-24 bg-muted/30">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
              Why Choose MilletBowl?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Disease control through traditional nutrition, not medication
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: Leaf,
                title: 'Ancient Grains',
                description: 'Traditional Indian millets packed with nutrients and fiber'
              },
              {
                icon: Heart,
                title: 'Diabetic-Friendly',
                description: 'Low glycemic index meals that help manage blood sugar naturally'
              },
              {
                icon: Users,
                title: 'Personalized Plans',
                description: 'Customized meal plans based on your health needs and preferences'
              },
              {
                icon: Shield,
                title: '100% Organic',
                description: 'No refined sugar, no preservatives, only pure organic ingredients'
              }
            ].map((benefit, index) => (
              <div
                key={index}
                className="bg-card rounded-xl p-6 shadow-sm hover:shadow-warm transition-shadow"
              >
                <benefit.icon className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-semibold mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Target Customers Section */}
      <TargetCustomersSection />

      {/* Hygiene Promise Section */}
      <HygienePromiseSection />

      {/* CTA Section */}
      <section className="py-16 md:py-24 bg-gradient-to-br from-primary/10 via-accent/10 to-secondary/20">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
            Ready to Transform Your Health?
          </h2>
          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join hundreds of satisfied customers who have improved their health with our
            millet-based meal plans
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center justify-center rounded-lg bg-primary px-8 py-3 text-base font-semibold text-primary-foreground shadow-warm hover:bg-primary/90 transition-all"
          >
            Get Started Today
            <ArrowRight className="ml-2 h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
