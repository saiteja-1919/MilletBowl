import { Clock, Sunrise, Sun, Coffee, Moon, Heart } from 'lucide-react';
import { Link } from '@tanstack/react-router';

export default function PersonalizedDietPlansPage() {
  const mealPlan = [
    {
      time: 'Morning (6:00 AM)',
      icon: Sunrise,
      meal: 'Wheatgrass Juice',
      description: 'Fresh wheatgrass juice to detoxify and energize your body',
      benefits: ['Detoxification', 'Boosts immunity', 'Rich in chlorophyll']
    },
    {
      time: 'Breakfast (8:00 AM)',
      icon: Sun,
      meal: 'Ragi/Foxtail Millet with Fenugreek',
      description: 'Warm millet porridge or dosa with fenugreek seeds',
      benefits: ['Low glycemic index', 'High in calcium', 'Regulates blood sugar']
    },
    {
      time: 'Lunch (12:30 PM)',
      icon: Clock,
      meal: 'Barnyard/Kodo/Little Millet Bowl',
      description: 'Wholesome millet bowl with seasonal vegetables and lentils',
      benefits: ['High fiber content', 'Sustained energy', 'Easy to digest']
    },
    {
      time: 'Snacks (4:00 PM)',
      icon: Coffee,
      meal: 'Proso/Browntop Millet Snacks',
      description: 'Light millet-based snacks like cutlets or energy balls',
      benefits: ['Healthy snacking', 'Prevents overeating', 'Nutrient-rich']
    },
    {
      time: 'Dinner (7:00 PM)',
      icon: Moon,
      meal: 'Jowar/Bajra with Vegetables',
      description: 'Jowar roti or bajra khichdi with mixed vegetables',
      benefits: ['Light on stomach', 'Promotes better sleep', 'Rich in minerals']
    }
  ];

  return (
    <div className="py-16 md:py-24">
      <div className="container max-w-5xl">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">
            Personalized Diet Plans
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Our expert nutritionists create customized meal plans tailored to your health
            conditions, preferences, and lifestyle. Here's an example of a diabetic-friendly daily
            plan.
          </p>
        </div>

        {/* Example Plan Badge */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-6 py-3 rounded-full font-semibold">
            <Heart className="h-5 w-5" />
            Example: Diabetic-Friendly Daily Plan
          </div>
        </div>

        {/* Meal Timeline */}
        <div className="space-y-8">
          {mealPlan.map((meal, index) => (
            <div
              key={index}
              className="bg-card rounded-xl p-6 md:p-8 shadow-sm hover:shadow-warm transition-all border border-border/50"
            >
              <div className="flex flex-col md:flex-row gap-6">
                <div className="flex items-start gap-4 md:w-1/3">
                  <div className="flex-shrink-0 w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                    <meal.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">{meal.time}</div>
                    <h3 className="text-xl font-semibold">{meal.meal}</h3>
                  </div>
                </div>
                <div className="md:w-2/3 space-y-3">
                  <p className="text-muted-foreground">{meal.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {meal.benefits.map((benefit, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent-foreground"
                      >
                        {benefit}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Customization Note */}
        <div className="mt-16 bg-gradient-to-br from-accent/10 to-primary/10 rounded-2xl p-8 md:p-12 text-center">
          <h2 className="text-2xl md:text-3xl font-display font-bold mb-4">
            Every Plan is Personalized
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-6">
            This is just one example. We customize every meal plan based on your specific health
            condition, dietary preferences, allergies, and lifestyle requirements.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/contact"
              className="inline-flex items-center justify-center rounded-lg bg-primary px-8 py-3 text-base font-semibold text-primary-foreground shadow-warm hover:bg-primary/90 transition-all"
            >
              Get Your Custom Plan
            </Link>
            <Link
              to="/subscription"
              className="inline-flex items-center justify-center rounded-lg border-2 border-primary px-8 py-3 text-base font-semibold text-primary hover:bg-primary/10 transition-all"
            >
              View Subscription Options
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
