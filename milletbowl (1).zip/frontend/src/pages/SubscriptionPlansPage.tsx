import { Check, Sparkles } from 'lucide-react';
import { Link } from '@tanstack/react-router';

export default function SubscriptionPlansPage() {
  const plans = [
    {
      name: 'Weekly Plan',
      price: 'Custom Pricing',
      description: 'Perfect for trying out our service or short-term needs',
      features: [
        '7 days of personalized meals',
        'Daily fresh delivery',
        'Customizable menu',
        'Nutritionist consultation',
        'Health tracking support',
        'Flexible modifications'
      ],
      popular: false
    },
    {
      name: 'Monthly Plan',
      price: 'Custom Pricing',
      description: 'Best value for consistent health transformation',
      features: [
        '30 days of personalized meals',
        'Daily fresh delivery',
        'Fully customizable menu',
        'Weekly nutritionist check-ins',
        'Detailed health tracking',
        'Priority customer support',
        'Free recipe book',
        'Meal prep guidance'
      ],
      popular: true
    }
  ];

  const customizationOptions = [
    'Health condition-based customization (diabetes, obesity, digestive issues)',
    'Dietary preferences (vegetarian, vegan, gluten-free)',
    'Spice level and taste preferences',
    'Portion size adjustments',
    'Meal timing flexibility',
    'Ingredient substitutions for allergies'
  ];

  return (
    <div className="py-16 md:py-24">
      <div className="container max-w-6xl">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-6">
            Subscription Plans
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Choose a plan that fits your lifestyle. All plans include personalized meal
            customization based on your health needs.
          </p>
        </div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-card rounded-2xl p-8 shadow-sm hover:shadow-warm transition-all border-2 ${
                plan.popular ? 'border-primary' : 'border-border/50'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                    <Sparkles className="h-4 w-4" />
                    Most Popular
                  </span>
                </div>
              )}
              <div className="text-center mb-6">
                <h3 className="text-2xl font-display font-bold mb-2">{plan.name}</h3>
                <div className="text-3xl font-bold text-primary mb-2">{plan.price}</div>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              <Link
                to="/contact"
                className={`block w-full text-center rounded-lg px-6 py-3 font-semibold transition-all ${
                  plan.popular
                    ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                    : 'border-2 border-primary text-primary hover:bg-primary/10'
                }`}
              >
                Get Started
              </Link>
            </div>
          ))}
        </div>

        {/* Customization Section */}
        <div className="bg-gradient-to-br from-accent/10 to-primary/10 rounded-2xl p-8 md:p-12">
          <h2 className="text-3xl font-display font-bold mb-6 text-center">
            Complete Customization
          </h2>
          <p className="text-lg text-muted-foreground text-center mb-8 max-w-3xl mx-auto">
            Every subscription plan can be fully customized to match your unique health profile and
            preferences. We work with you to create the perfect meal plan.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
            {customizationOptions.map((option, index) => (
              <div key={index} className="flex items-start gap-3 bg-card rounded-lg p-4">
                <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-sm">{option}</span>
              </div>
            ))}
          </div>
        </div>

        {/* How It Works */}
        <div className="mt-16">
          <h2 className="text-3xl font-display font-bold mb-8 text-center">How It Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                title: 'Share Your Details',
                description:
                  'Fill out our consultation form with your health condition and preferences'
              },
              {
                step: '2',
                title: 'Get Your Plan',
                description:
                  'Our nutritionists create a personalized meal plan just for you'
              },
              {
                step: '3',
                title: 'Enjoy Fresh Meals',
                description:
                  'Receive freshly cooked, healthy meals delivered to your doorstep daily'
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary text-primary-foreground text-2xl font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
