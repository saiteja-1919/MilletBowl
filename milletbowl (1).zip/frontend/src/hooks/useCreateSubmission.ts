import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';

interface SubmissionData {
  name: string;
  healthCondition: string;
  subscriptionInterest: string;
}

export function useCreateSubmission() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (data: SubmissionData) => {
      if (!actor) {
        throw new Error('Actor not initialized');
      }

      // Note: Backend expects email and message, but we're sending healthCondition and subscriptionInterest
      // This is a workaround until backend is updated
      await actor.addEntry(data.name, data.healthCondition, data.subscriptionInterest);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['submissions'] });
    }
  });
}
